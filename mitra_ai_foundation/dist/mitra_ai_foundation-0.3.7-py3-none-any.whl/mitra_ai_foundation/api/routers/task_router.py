"""
Base router for task-related endpoints.

This module provides the foundation for task management endpoints.
Specific applications should define their own task routers in their respective packages.
"""
from fastapi import APIRouter, HTTPException

from ..services.task_service import send_task_to_celery, parse_task_result
from ..services.redis_service import get_task_info
from ..models.schemas import TaskResponse, TaskStatusResponse

# Create a base router that can be extended by applications
base_router = APIRouter(tags=["tasks"])

@base_router.get("/tasks/{task_id}", response_model=TaskStatusResponse)
def get_task_status(task_id: str):
    """
    Get the status of a task.
    
    This endpoint retrieves task status from Redis.
    """
    # Get task info from Redis
    task_info = get_task_info(task_id)
    
    if task_info.get("status") == "NOT_FOUND":
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    
    # Parse result if it exists
    result = parse_task_result(task_info.get("result"))
    
    return TaskStatusResponse(
        task_id=task_id,
        status=task_info.get("status", "PENDING"),
        progress=task_info.get("progress", 0),
        result=result,
        message=task_info.get("message")
    )